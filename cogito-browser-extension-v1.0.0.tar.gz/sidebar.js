// Sidebar functionality for Cogito browser extension
class CogitoSidebar {
  constructor() {
    this.baseUrl = null;
    this.authToken = null;
    this.currentUser = null;
    this.currentClient = null;
    this.captureEnabled = false;
    this.isAISite = false;
    
    this.init();
  }

  async init() {
    // Check if we're on an AI site
    const tab = await this.getCurrentTab();
    this.isAISite = this.checkIfAISite(tab?.url);
    
    // Load saved state
    await this.loadSavedState();
    
    // Set up event listeners
    this.setupEventListeners();
    
    // Update UI based on auth state
    this.updateUIState();
    
    // Show/hide capture section based on site
    if (this.isAISite) {
      document.getElementById('capture-section').classList.remove('hidden');
    }
  }

  async getCurrentTab() {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        resolve(tabs[0]);
      });
    });
  }

  checkIfAISite(url) {
    if (!url) return false;
    return url.includes('claude.ai') || url.includes('chat.openai.com');
  }

  async loadSavedState() {
    const data = await chrome.storage.local.get([
      'authToken', 
      'currentUser', 
      'currentClient', 
      'baseUrl',
      'captureEnabled'
    ]);
    
    this.authToken = data.authToken;
    this.currentUser = data.currentUser;
    this.currentClient = data.currentClient;
    this.baseUrl = data.baseUrl || 'http://localhost:3000';
    this.captureEnabled = data.captureEnabled || false;
    
    // Update capture toggle
    if (this.authToken && this.isAISite) {
      document.getElementById('capture-toggle').checked = this.captureEnabled;
      this.updateCaptureStatus();
    }
  }

  setupEventListeners() {
    // Login form
    document.getElementById('login-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleLogin();
    });

    // Logout button
    document.getElementById('logout-btn').addEventListener('click', () => {
      this.handleLogout();
    });

    // Client selector
    document.getElementById('client-selector').addEventListener('change', (e) => {
      this.handleClientChange(e.target.value);
    });

    // Capture toggle
    document.getElementById('capture-toggle').addEventListener('change', (e) => {
      this.handleCaptureToggle(e.target.checked);
    });

    // Query form
    document.getElementById('query-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleQuery();
    });

    // Clear response
    document.getElementById('clear-response').addEventListener('click', () => {
      this.clearResponse();
    });
  }

  async handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    this.showLoading();
    
    try {
      // Try local first, then hosted
      const endpoints = [
        'http://localhost:3000',
        'https://cogito-app.onrender.com'
      ];
      
      let loginResponse = null;
      let workingEndpoint = null;
      
      for (const endpoint of endpoints) {
        try {
          const response = await fetch(`${endpoint}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
          });
          
          if (response.ok) {
            loginResponse = await response.json();
            workingEndpoint = endpoint;
            break;
          }
        } catch (err) {
          continue;
        }
      }
      
      if (!loginResponse) {
        throw new Error('Invalid credentials or server unavailable');
      }
      
      this.baseUrl = workingEndpoint;
      this.authToken = loginResponse.token;
      this.currentUser = loginResponse.user;
      
      // Save to storage
      await chrome.storage.local.set({
        authToken: this.authToken,
        currentUser: this.currentUser,
        baseUrl: this.baseUrl
      });
      
      // Get user's clients
      await this.loadUserClients();
      
    } catch (error) {
      this.showError('auth-error', error.message);
    } finally {
      this.hideLoading();
    }
  }

  async loadUserClients() {
    try {
      const response = await fetch(`${this.baseUrl}/api/user/clients`, {
        headers: {
          'Authorization': `Bearer ${this.authToken}`
        }
      });
      
      if (!response.ok) throw new Error('Failed to load clients');
      
      const clients = await response.json();
      
      if (clients.length === 1) {
        // Auto-select single client
        this.currentClient = clients[0];
        await chrome.storage.local.set({ currentClient: this.currentClient });
        this.updateUIState();
      } else if (clients.length > 1) {
        // Show client selector
        this.populateClientSelector(clients);
        document.getElementById('client-selector-wrapper').classList.remove('hidden');
        this.updateUIState();
      }
    } catch (error) {
      console.error('Error loading clients:', error);
      this.showError('auth-error', 'Failed to load clients');
    }
  }

  populateClientSelector(clients) {
    const selector = document.getElementById('client-selector');
    selector.innerHTML = '<option value="">Select Client...</option>';
    
    clients.forEach(client => {
      const option = document.createElement('option');
      option.value = client.client_id;
      option.textContent = client.name;
      selector.appendChild(option);
    });
    
    // Select current client if set
    if (this.currentClient) {
      selector.value = this.currentClient.client_id;
    }
  }

  async handleClientChange(clientId) {
    if (!clientId) return;
    
    const selector = document.getElementById('client-selector');
    const selectedOption = selector.options[selector.selectedIndex];
    
    this.currentClient = {
      client_id: parseInt(clientId),
      name: selectedOption.textContent
    };
    
    await chrome.storage.local.set({ currentClient: this.currentClient });
    
    // Notify background script of client change
    chrome.runtime.sendMessage({
      type: 'CLIENT_CHANGED',
      client: this.currentClient
    });
  }

  async handleLogout() {
    await chrome.storage.local.clear();
    this.authToken = null;
    this.currentUser = null;
    this.currentClient = null;
    this.captureEnabled = false;
    
    // Reset UI
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
    document.getElementById('capture-toggle').checked = false;
    
    this.updateUIState();
  }

  async handleCaptureToggle(enabled) {
    this.captureEnabled = enabled;
    await chrome.storage.local.set({ captureEnabled: enabled });
    
    // Notify content scripts
    const tab = await this.getCurrentTab();
    if (tab) {
      chrome.tabs.sendMessage(tab.id, {
        type: 'TOGGLE_CAPTURE',
        enabled: enabled,
        client: this.currentClient
      });
    }
    
    this.updateCaptureStatus();
  }

  updateCaptureStatus() {
    const statusEl = document.getElementById('capture-status');
    if (this.captureEnabled) {
      statusEl.textContent = `Capturing to ${this.currentClient?.name || 'Cogito'}`;
      statusEl.style.color = '#059669';
    } else {
      statusEl.textContent = 'Capture disabled';
      statusEl.style.color = '#6b7280';
    }
  }

  async handleQuery() {
    const queryInput = document.getElementById('query-input');
    const query = queryInput.value.trim();
    
    if (!query) return;
    
    const submitBtn = document.getElementById('submit-query');
    const btnText = submitBtn.querySelector('.btn-text');
    const spinner = submitBtn.querySelector('.loading-spinner');
    
    // Show loading state
    submitBtn.disabled = true;
    btnText.classList.add('hidden');
    spinner.classList.remove('hidden');
    
    try {
      const response = await fetch(`${this.baseUrl}/api/query`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.authToken}`,
          'Content-Type': 'application/json',
          'X-Client-ID': this.currentClient?.client_id
        },
        body: JSON.stringify({ query })
      });
      
      if (!response.ok) throw new Error('Query failed');
      
      const result = await response.json();
      this.displayResponse(result.response);
      
    } catch (error) {
      this.displayResponse(`Error: ${error.message}`, true);
    } finally {
      // Reset button state
      submitBtn.disabled = false;
      btnText.classList.remove('hidden');
      spinner.classList.add('hidden');
    }
  }

  displayResponse(content, isError = false) {
    const responseArea = document.getElementById('response-area');
    const responseContent = document.getElementById('response-content');
    
    responseArea.classList.remove('hidden');
    responseContent.textContent = content;
    
    if (isError) {
      responseContent.style.color = '#dc2626';
    } else {
      responseContent.style.color = '#4b5563';
    }
  }

  clearResponse() {
    document.getElementById('response-area').classList.add('hidden');
    document.getElementById('response-content').textContent = '';
    document.getElementById('query-input').value = '';
  }

  updateUIState() {
    const authSection = document.getElementById('auth-section');
    const mainInterface = document.getElementById('main-interface');
    
    if (this.authToken && this.currentClient) {
      // Show main interface
      authSection.classList.add('hidden');
      mainInterface.classList.remove('hidden');
      
      // Update user info
      document.getElementById('user-email').textContent = this.currentUser?.email || '';
      
    } else if (this.authToken && !this.currentClient) {
      // Waiting for client selection
      authSection.classList.add('hidden');
      mainInterface.classList.remove('hidden');
      document.getElementById('user-email').textContent = this.currentUser?.email || '';
      
    } else {
      // Show auth
      authSection.classList.remove('hidden');
      mainInterface.classList.add('hidden');
    }
  }

  showLoading() {
    document.getElementById('loading-overlay').classList.remove('hidden');
  }

  hideLoading() {
    document.getElementById('loading-overlay').classList.add('hidden');
  }

  showError(elementId, message) {
    const errorEl = document.getElementById(elementId);
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.classList.remove('hidden');
      setTimeout(() => {
        errorEl.classList.add('hidden');
      }, 5000);
    }
  }
}

// Initialize sidebar when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new CogitoSidebar();
});